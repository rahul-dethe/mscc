##
## gamcleanup.py
##
## A more elegant way to clean up the mess?!!
##
## This code was written at CSIT, ANU, Canberra
##
## @author V.Ganesh
## @date 24 Oct 2006
##

# clen up command
#CLEANUP_CMD = "rm -f " + OUTPUT_PREFIX + "final.dm " \
#              + OUTPUT_PREFIX + "final.sij " \
#              + OUTPUT_PREFIX + "final.fck " \
#              + OUTPUT_PREFIX + "pij " \
#              + OUTPUT_PREFIX + "sij " \
#              + OUTPUT_PREFIX + "grdfil " \
#              + ENERGY_FILE

# clean up client command
#CLEANUP_CLIENT_CMD = "rm -f " + OUTPUT_PREFIX + "pij.new " \
#                     + OUTPUT_PREFIX + "sij.new " \
#                     + OUTPUT_PREFIX + "grdfil.new " \
#                     + "energy-" + HOST_SUFIX + ".out.new"#

def cleanupScheduler():
    pass

def cleanupExecuter():
    pass

