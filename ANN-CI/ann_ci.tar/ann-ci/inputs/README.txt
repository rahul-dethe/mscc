To download input files kindly follow the commands :

cd ~/
git clone https://github.com/rahul-dethe/ann_test_inputs.git

If a directory by name " ann_test_inputs " is visible means the test input files are downloaded successfully.